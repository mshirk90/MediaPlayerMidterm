;( function( $ ) {

	$( '.wolf-jplayer-color' ).wpColorPicker();
	
} )( jQuery );